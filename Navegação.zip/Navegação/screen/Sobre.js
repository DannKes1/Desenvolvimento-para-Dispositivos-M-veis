import React from "react";
import { View, Text, Button } from "react-native";

export default function Sobre({navigation}){
return(
<View>
<Text>Tela sobre</Text>
<Button 
title = "Voltar para home" onPress = {() => {navigation.goBack()}}>
</Button>


</View>

)
}