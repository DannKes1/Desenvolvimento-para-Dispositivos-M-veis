import React from "react";
import { View, Text, Button } from "react-native";

export default function Detalhes({navigation}){
return(
<View>
<Text>Tela detalhes</Text>
<Button 
title = "Voltar para home" onPress = {() => {navigation.goBack()}}>

</Button>


</View>

)
}